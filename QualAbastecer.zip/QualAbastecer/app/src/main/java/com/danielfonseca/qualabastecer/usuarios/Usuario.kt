package com.danielfonseca.qualabastecer.usuarios


class Usuario {

    var nome: String? = null
    var email: String? = null
}
