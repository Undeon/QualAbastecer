package com.danielfonseca.qualabastecer.veiculos

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.danielfonseca.qualabastecer.R

class GerenciarVeiculosActivity : AppCompatActivity() {

override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_gerenciar_veiculos)
    //if (carrosCadastrados == 0){
    }
}
